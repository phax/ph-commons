#!/bin/env python
from PySide.QtGui import QApplication
app = QApplication([])
args = {}

